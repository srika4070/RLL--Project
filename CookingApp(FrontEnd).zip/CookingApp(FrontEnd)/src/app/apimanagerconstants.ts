import { environment } from 'src/environments/environment';

export class ApiManagerConstants {

  /*
  * URLs
  */

  public static RES_MAPPING_TREE_FIELDS_URL = 'assets/responsemappingfields.json';

  public static RES_MAPPING_CLASS_URL = 'assets/responsemappingrequestclass.json';

  public static REQ_MAPPING_TREE_FIELDS_URL = 'assets/requestmappingfields.json';

  public static REQ_MAPPING_CLASS_URL = 'assets/requestmappingrequestclass.json';

  public static SERVICE_TAB_COMBO_URL = 'assets/servicetabcombo.json';

  public static OPERATIONS_URL = 'assets/operations.json';

  public static REQ_CLASS_URL = 'assets/requestclass.json';

  public static RES_CLASS_URL = 'assets/responseclass.json';

  public static  SERVICE_LIST_GRID_URL = 'assets/servicelistgrid.json';

  public static SERVICE_LIST_GRID_HTTP_JSON_URL = 'assets/servicelistgridjsontohttp.json';

  public static MAP_FIELDS_JSON_URL = 'assets/mapfields.json';

  public static SAVE_SERVICE_END_POINT_URL = '/services';

  public static CREATE_SERVICE_ENDPOINT_HARDCODED = 'assets/servicedefresponse.json';

  /*
  * Constants for Communication and Hiding
  */

  public static DISPLAY_REQ_RES_TAB = 'YES';

  public static DISPLAY_OPERATION_TAB = 'YES';

  public static CREATE_MODE = 'create';

  public static EDIT_MODE = 'edit';

  public static SPINNING_BTN_CLS = 'spinner-border spinner-border-sm';

  public static NON_SPINNING_BTN_CLS = '';

  public static DOT_APPENDER = '.';

  public static SPLITTER_APPENDER = ',';



  // Constants for Save or Failure of Data

  public static SAVE_REQMAPPING_MSG = 'Request Mapping Saved Sucessfully';

  public static FAIL_REQMAPPING_MSG = 'Failed to Save Request Mapping';

  public static SAVE_REQCLASS_MSG = 'Request Class Saved Sucessfully';

  public static FAIL_REQCLASS_MSG = 'Failed to Save Request Class';


  public static SAVE_OPERATION_MSG = 'Operation Saved Sucessfully';

  public static FAIL_OPERATION_MSG = 'Failed to Save Operation';

  public static SAVE_RESMAPPING_MSG = 'Response Mapping Saved Sucessfully';

  public static FAIL_RESMAPPING_MSG = 'Failed to Save Response Mapping';

  public static SAVE_RESCLASS_MSG = 'Response Class Saved Sucessfully';

  public static FAIL_RESCLASS_MSG = 'Failed to Save Response Class';

  public static FAIL_SAVE_SERVICE = 'Failed to Save Service Data';

  public static SUCESS_SAVE_SERVICE = 'Service Data Saved Sucessfully';

  public static RETRIVAL_OF_DATA_IS_SUCESS = 'Retrival of Data is Sucessful';

  public static PLEASE_SELECT_TYPE = 'Please Select Service Type';

  public static NAME_ERROR = 'Please Provide Service Name';

  public static VERSION_ERROR = 'Please Provide Version';

  public static PLESE_PROVIDE_SCHEME_LOCATION = 'Please Provide Schema Location';

  public static PLESE_PROVIDE_WSDL_LOCATION = 'Please Provide WSDL Location';

  public static PLESE_PROVIDE_PACK_MAME = 'Please Provide Package Name';

  public static PLESE_PROVIDE_HTTP_METHOD = 'Please Provide Http Method';

  public static PLESE_PROVIDE_SOAPVERSION_MAME = 'Please Provide Soap Version';

  public static PLEASE_SELECT_BACKENDSYSTEM = 'Please Select the Backend System';

  public static OPERATION_NAME_IS_REQUIRED = 'Operation Name is Required';

  public static RESPONSE_CLS_IS_REQUIRED = 'Response Class is Required';

  public static REQUEST_CLS_IS_REQUIRED = 'Request Class is Required';

  public static REQUEST_JSON_FILE_IS_REQUIRED = 'Request JSON File is Required';

  public static RESPONSE_JSON_FILE_IS_REQUIRED = 'Response JSON File is Required';

  /* Service Tab Type Constants*/

  public static JSON_TO_SOAP = 'JSON2SOAP';

  public static JSON_TO_HTTP = ' JSON2HTTP';

  public static JSON_TO_JSON = 'JSON2JSON';

  public static JSON_TO_DB = 'JSON2DB';

  public static JSON_TO_ISO = 'JSON2ISO';

  public static REQUEST_KEY_ROOT_NODE = 'RequestID';

  public static RESPONSE_KEY_ROOT_NODE = 'ResponseID';

  public static SUCESS_KEY = 'success';

  /* End Points for Server Integration */
  static CREATE_SERVICE_ENDPOINT = environment.config.serverUrl + 'services';
  /* End Points for Server Integration */

  static SEARCH_SERVICES_BY_NAME = ApiManagerConstants.CREATE_SERVICE_ENDPOINT + '/search/name/';

  static SEARCH_SERVICES_BY_TYPE = ApiManagerConstants.CREATE_SERVICE_ENDPOINT + '/search/type/';

  static DELETE_SERVICE = ApiManagerConstants.CREATE_SERVICE_ENDPOINT + '/' ;


}
