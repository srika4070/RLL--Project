﻿import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { AuthenticationService, AlertService } from '../_services';
import { LoginFlagService } from '../loginflag.service';
import { Performanceconstants } from '../constants/performanceconstants';
import { PerformancemanageService } from '../services/performancemanage.service';


@Component({ templateUrl: 'login.component.html'})
export class LoginComponent implements OnInit {
    loginForm: FormGroup;
    loading = false;
    submitted = false;
    returnUrl: string;
    showError = false;
    errorMsg: string;

    constructor(
        private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private authenticationService: AuthenticationService,
        private alertService: AlertService,
        private loginStatusService: LoginFlagService,
        private performanceManagerService: PerformancemanageService
    ) {
        // redirect to home if already logged in
        if (this.authenticationService.currentUserValue) {
            this.router.navigate(['/']);
        }
    }

    ngOnInit() {
        this.loginForm = this.formBuilder.group({
            username: ['', Validators.required],
            authinfo: ['', Validators.required]
        });

        // get return url from route parameters or default to '/'
        this.returnUrl = this.route.snapshot.queryParams.returnUrl || '/';
    }

    // convenience getter for easy access to form fields
    get f() { return this.loginForm.controls; }

    onSubmit() {
        this.submitted = true;

        // reset alerts on submit
        this.alertService.clear();

        // stop here if form is invalid
        if (this.loginForm.invalid) {
            return;
        }

        console.log('Inside Login');
        this.loading = true;
        const dataLogin = {
          username: '',
          authinfo: ''
        };
        console.log('Inside Login1===============================================================');
        dataLogin.username = this.f.username.value;
        dataLogin.authinfo = this.f.authinfo.value;
        console.log(dataLogin);
        this.performanceManagerService.doLogin(dataLogin).subscribe(
          (res) => {
            console.log('Inside Response Sucess =======================================');
            console.log(res);
            if (res.status){
              this.loginStatusService.setLoginStatus(true);
              localStorage.setItem(Performanceconstants.USERNAME_KEY, dataLogin.username);
              localStorage.setItem('isLoggedIn', 'YES');

              let logintype = res.model.logintype;
              if(logintype!=null && logintype===1){
                const completeUrl = this.returnUrl + '/home';
                this.router.navigate([completeUrl]);
              }else{
                const completeUrl = this.returnUrl + '/homepageuser';
                this.router.navigate([completeUrl]);
              }
             
            }else{
              const error = res.errMessages[0].errMessage;
              console.log('TEST ERROR');
              console.log(error);
              this.errorMsg = error;
              this.showError = true;
              this.alertService.error(error);
              this.loading = false;
            }
          },
          (error) => {
            console.log('Inside Response Error =======================================');
            const errorTemp = error;
            console.log('TEST ERROR');
            console.log(errorTemp);
            this.errorMsg = errorTemp;
            this.showError = true;
            this.alertService.error(errorTemp);
            this.loading = false;
            this.loading = false;
          }

        );



    }

    navToLoginUser(){
      this.router.navigate(['/loginuser']);
    }
}
