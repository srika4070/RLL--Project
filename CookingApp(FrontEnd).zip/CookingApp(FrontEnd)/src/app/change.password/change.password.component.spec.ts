import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Change.PasswordComponent } from './change.password.component';

describe('Change.PasswordComponent', () => {
  let component: Change.PasswordComponent;
  let fixture: ComponentFixture<Change.PasswordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Change.PasswordComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Change.PasswordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
