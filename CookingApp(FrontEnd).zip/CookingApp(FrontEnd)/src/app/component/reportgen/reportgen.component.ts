import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { PerformancemanageService } from 'src/app/services/performancemanage.service';
import { Performanceconstants } from 'src/app/constants/performanceconstants';
import { NgbDateStruct, NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { AgGridAngular } from 'ag-grid-angular';

@Component({
  selector: 'app-reportgen',
  templateUrl: './reportgen.component.html',
  styleUrls: ['./reportgen.component.scss']
})
export class ReportgenComponent implements OnInit {

  public rowSelection;
  public defaultColDef;
  public gridApi;
  public gridColumnApi;
  rowData: [];
  closeResult='';

  disabledeviceid = true;
  validationError: string;
  reportgenform: FormGroup;
  savereportform: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;
  sucessMsg: string;
  showFailure: boolean;
  failureMsg: string;
  showSucess: boolean;
  showError: boolean;
  disableDuringSave: boolean;
  loadingServiceClassBtn: string;
  showReportName =false;
  showBtnReport= false;
  showBtnReportDefault = true;

  MinutesList: any;
  DeviceList: any;
  dynamicId;

  /* Grid Information */

  @ViewChild('agGrid') agGrid: AgGridAngular;
  columnDefs = [

    {headerName: 'Date & Time', field: 'localdatetime', sortable: true,  resizable: true, width: 250},
    {headerName: 'Availability', field: 'availability', sortable: true,  resizable: true, width: 200},
    {headerName: 'Interface Status', field: 'interfacestatus', sortable: true, resizable: true, width: 300},
    {
      headerName: 'Utilization',
      children: [
          { headerName: 'CPU', field: 'cpu' },
          { headerName: 'Memory', field: 'memory' },
          { headerName: 'Disk', field: 'disk' }
      ]
    }

  ];

 /*End of  Grid Information */
  constructor(private performancemanageService: PerformancemanageService,
              private formBuilder: FormBuilder,
              private eref: ElementRef,
              private modalService: NgbModal) {
                this.rowSelection = 'single';

                this.performancemanageService.getDeviceInformation().subscribe(
                  (resp) => {
                    if (resp.status){
                      this.DeviceList = resp.model;
                    }else{
                      const errorV = resp.errMessages[0].errMessage;
                      this.failureHandling(errorV);
                    }
                  },
                  (errorResp) => {
                    this.failureHandling(errorResp);
                  }
                );

                this.performancemanageService.getIntervalInformation().subscribe(
                  (resp) => {
                    if (resp.status){
                      this.MinutesList = resp.model;
                    }else{
                      const errorV = resp.errMessages[0].errMessage;
                      this.failureHandling(errorV);
                    }
                  },
                  (errorResp) => {
                    this.failureHandling(errorResp);
                  }
                );


              }

  get f() { return this.reportgenform.controls; }

  ngOnInit(): void {
    this.reportgenform = this.formBuilder.group({
      devicename: ['', [Validators.required]],
      fromdate: ['', Validators.required],
      deviceid: new FormControl( {value: '', disabled: true}, Validators.required),
      todate: ['', Validators.required],
      minutes: ['', Validators.required],
      reportname: ['', [Validators.required]]
      });

   }

  onClick(event) {
    console.log('Hello me world');
    console.log(event);
    if (this.dynamicId === undefined){
      console.log('Dynamic id ===============');
    }
    else if (!this.eref.nativeElement.contains(event.target)) {
      const self = this;
      // tslint:disable-next-line:only-arrow-functions
      setTimeout( function(){
        self.dynamicId.close();
      }, 10);
    }
  }

  openDatepicker(id){
    this.dynamicId = id;
   }

   get reportname(){
    return this.reportgenform.get('reportname');
   }

  get devicename(){
    return this.reportgenform.get('devicename');
  }

  get fromdate(){
    return this.reportgenform.get('fromdate');
  }

  get todate(){
    return this.reportgenform.get('todate');
  }


  get minutes(){
    return this.reportgenform.get('minutes');
  }

  get deviceid(){
    return this.reportgenform.get('deviceid');
  }

  failureHandling(err: string){
    this.loading = false;
    this.showFailure = true;
    this.showSucess = false;
    this.failureMsg = err;
    this.sucessMsg = '';
    this.loadingServiceClassBtn = Performanceconstants.NON_SPINNING_BTN_CLS;
  }

  sucessHandling(msg: string){
    this.loading = false;
    this.showFailure = false;
    this.showSucess = true;
    this.failureMsg = '';
    this.sucessMsg = msg;
    this.loadingServiceClassBtn = Performanceconstants.NON_SPINNING_BTN_CLS;
  }

  changeMinutes(e){

  }

  changeDevice(deviceEvent){

    this.sucessMsg = '';
    this.showSucess = false;
    this.showError = false;
    this.failureMsg = '';
    console.log(deviceEvent);
    // tslint:disable-next-line:no-debugger

    const deviceType = deviceEvent.target.value;

    this.performancemanageService.getDeviceIdForDeviceType(deviceType).subscribe(
      (respSucess) => {
        if (respSucess.status){
           this.reportgenform.controls.deviceid.setValue(respSucess.model.deviceip);
        } else{
          const errorResp = respSucess.errMessages[0].errMessage;
          this.failureHandling(errorResp);
        }
      },
      (errorResp) => {
        this.failureHandling(errorResp);
      }
    );

  }

  saveReport(){
    console.log('save report');

    this.loading = true;
    this.loadingServiceClassBtn = Performanceconstants.SPINNING_BTN_CLS;

    let reportName = this.reportgenform.get('reportname').value;

    if(null==reportName ||reportName === ''){
      this.validationError = 'Report Name Cannot be Empty';
      this.failureHandling(this.validationError);
      this.reportgenform.enable();
      return;
    }

    if (this.checkForFormInValidity()) {
        this.failureHandling(this.validationError);
        this.reportgenform.enable();
        return;
    } else {

      this.reportgenform.disable();
// Need to Call Backend and Save the Data or Create a Service
  const temp = this.reportgenform.value;

  if (temp.devicename === ''){
     temp.devicename = null;
  }

  if (temp.fromdate === ''){
    temp.fromdate = null;
  }

  if (temp.fromdate){
    temp.fromdate = this.convertToValidString(temp.fromdate);
  }

  if (temp.deviceid === ''){
    temp.deviceid = null;
  }

  if (temp.todate === ''){
    temp.todate = null;
  }

  if (temp.todate){
    temp.todate = this.convertToValidString(temp.todate);
  }

  if (temp.minutes === ''){
    temp.minutes = null;
  }

  let reportname = this.reportgenform.get('reportname').value;

  const reportGenInfo = {
    devicename: temp.devicename,
    minutes: temp.minutes,
    deviceid: temp.deviceid,
    fromdate: temp.fromdate,
    todate: temp.todate,
    reportname: reportname

  };

  // Save the Report Information

  this.performancemanageService.saveReportInformation(reportGenInfo).subscribe(
    (res) => {
      const status = res.status;

      if (status){

        const sucessMsg = res.message;
        this.reportgenform.enable();
        this.rowData = res.model;

        this.sucessHandling(sucessMsg);
      }else{
        const errorV = res.errMessages[0].errMessage;
        this.failureHandling(errorV);
        this.reportgenform.enable();
      }

    },
    (error) => {
      this.reportgenform.enable();
      this.failureHandling(error);
    }
  );

  debugger;

}




}

  generateReport(){
   console.log('Generate Report');
   this.loading = true;
   this.loadingServiceClassBtn = Performanceconstants.SPINNING_BTN_CLS;
   if (this.checkForFormInValidity()) {
  this.failureHandling(this.validationError);
  this.reportgenform.enable();
  } else {
  this.reportgenform.disable();
// Need to Call Backend and Save the Data or Create a Service
  const temp = this.reportgenform.value;

  if (temp.devicename === ''){
     temp.devicename = null;
  }

  if (temp.fromdate === ''){
    temp.fromdate = null;
  }

  if (temp.fromdate){
    temp.fromdate = this.convertToValidString(temp.fromdate);
  }

  if (temp.deviceid === ''){
    temp.deviceid = null;
  }

  if (temp.todate === ''){
    temp.todate = null;
  }

  if (temp.todate){
    temp.todate = this.convertToValidString(temp.todate);
  }

  if (temp.minutes === ''){
    temp.minutes = null;
  }

  const reportGenInfo = {
    devicename: temp.devicename,
    minutes: temp.minutes,
    deviceid: temp.deviceid,
    fromdate: temp.fromdate,
    todate: temp.todate

  };

  this.performancemanageService.generateReportInformation(reportGenInfo).subscribe(
    (res) => {
      const status = res.status;

      if (status){

        const sucessMsg = res.message;
        this.reportgenform.enable();
        this.rowData = res.model;

        this.sucessHandling(sucessMsg);
      }else{
        const errorV = res.errMessages[0].errMessage;
        this.failureHandling(errorV);
        this.reportgenform.enable();
      }

    },
    (error) => {
      this.reportgenform.enable();
      this.failureHandling(error);
    }
  );

}


}

  generateChart(){

   console.log('Inside the Generate Chart Function');

  }

  checkForFormInValidity() {
    const status = false;
    const devicename = this.reportgenform.get('devicename').value;
    const fromdate = this.reportgenform.get('fromdate').value;
    const deviceid = this.reportgenform.get('deviceid').value;
    const todate = this.reportgenform.get('todate').value;
    const minutes =  this.reportgenform.get('minutes').value;

    if (devicename == null || devicename === '') {
      this.validationError = Performanceconstants.DEVICENAME_ERROR;
      return true;
  } else if (fromdate == null || fromdate === '') {
      this.validationError = Performanceconstants.FROMDATE_ERROR;
      return true;
  } else if ((deviceid == null || deviceid === '')) {
      this.validationError = Performanceconstants.DEVICEID_ERROR;
      return true;
  } else if ((todate == null || todate === '')) {
    this.validationError = Performanceconstants.TODATE_ERROR;
    return true;
  }else if ((minutes == null || minutes === '')) {
    this.validationError = Performanceconstants.MINUTES_ERROR;
    return true;
  }else {

    return false;
  }

}



convertToValidString(jsonDateObj){
  // YYYY-MM-DD
  if (jsonDateObj){
  return jsonDateObj.year + '-' + jsonDateObj.month + '-' +  jsonDateObj.day;
  }else{
    return '';
  }
}

onGridReady(params) {
  console.log('This is Grid On Ready');
  this.gridApi = params.api;
  this.gridColumnApi = params.columnApi;
}


openDialog() {

  this.showReportName = true;
  this.showBtnReport = true;
  this.showBtnReportDefault = false;
}



}

