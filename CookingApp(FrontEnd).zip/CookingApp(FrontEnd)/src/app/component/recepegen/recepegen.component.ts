import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertService, AuthenticationService } from 'src/app/_services';
import { Performanceconstants } from 'src/app/constants/performanceconstants';
import { LoginFlagService } from 'src/app/loginflag.service';
import { PerformancemanageService } from 'src/app/services/performancemanage.service';

@Component({
  selector: 'app-recepegen',
  templateUrl: './recepegen.component.html',
  styleUrls: ['./recepegen.component.scss']
})
export class RecepegenComponent implements OnInit {

  recipeForm: FormGroup;

  loading = false;
  submitted = false;
  returnUrl: string;
  sucessMsg: string;
  showFailure: boolean;
  failureMsg: string;
  showSucess: boolean;
  disableDuringSave: boolean;
  loadingServiceClassBtn: string;
  recipeCategories: any[];
  errorMsg: string;
  fileToUpload: File | null = null;
  MULTI_PART_FILE_KEY='recipeFile';

  constructor(private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private authenticationService: AuthenticationService,
    private alertService: AlertService,
    private loginStatusService: LoginFlagService,
    private performanceManagerService: PerformancemanageService) { }

  ngOnInit(): void {
    this.recipeForm = this.formBuilder.group({
      name: ['', Validators.required],
      ingredient: ['', Validators.required],
      steps: ['', Validators.required],
      recipecatname: ['', Validators.required],
      show:['',Validators.required],
      recipeFile: [null, Validators.required]
    });

    this.performanceManagerService.getRecipeCategories().subscribe(responseData => {
      this.recipeCategories = responseData.model;
    });

  }

  get f() { return this.recipeForm.controls; }

  get multipartFile(){
    return this.recipeForm.get(this.MULTI_PART_FILE_KEY);
  }


  onSubmit() {
    if (this.recipeForm) {
      // Form is valid, proceed with submission
      const formData = new FormData();
      formData.append('name', this.recipeForm.get('name').value);
      formData.append('ingredient', this.recipeForm.get('ingredient').value);
      formData.append('steps', this.recipeForm.get('steps').value);
      let checkBoxShowTemp = "0";
      let checkBoxShow = this.recipeForm.get('show').value;
      if(checkBoxShow===true){
        checkBoxShowTemp = "1";
      }
      formData.append('show', checkBoxShowTemp);
      formData.append('recipecatname', this.recipeForm.get('recipecatname').value);
      formData.append('recipeFile', this.fileToUpload, this.fileToUpload.name);

      this.performanceManagerService.submitRecipe(formData).subscribe(
        (res) => {
          const status = res.status;
          if (status){
            const sucessMsg = res.sucessMsg;
            this.recipeForm.enable();
            this.sucessHandling(sucessMsg);
            alert(sucessMsg);
          }else{
            const errorV = res.errMessages[0].errMessage;
            alert(errorV);
            this.failureHandling(errorV);
            this.recipeForm.enable();
          }
        },
        (error) => {
          alert(error);
          this.failureHandling(error);
        }
      );
    } else {
      // Form is invalid, display error messages
      this.failureHandling('Invalid Data');
    }
  }

  failureHandling(err: string){
    this.loading = false;
    this.showFailure = true;
    this.showSucess = false;
    this.failureMsg = err;
    this.sucessMsg = '';
    this.loadingServiceClassBtn = Performanceconstants.NON_SPINNING_BTN_CLS;
  }

  sucessHandling(msg: string){
    this.loading = false;
    this.showFailure = false;
    this.showSucess = true;
    this.failureMsg = '';
    this.sucessMsg = msg;
    this.loadingServiceClassBtn = Performanceconstants.NON_SPINNING_BTN_CLS;
  }
  
  onFileChange(eventData: any){
    console.log('Event Data : '+ eventData);
    this.fileToUpload = eventData.target.files.item(0);
  }

}
