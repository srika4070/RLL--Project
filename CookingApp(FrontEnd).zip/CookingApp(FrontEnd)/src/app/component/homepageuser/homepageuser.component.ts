import { Component, OnInit } from '@angular/core';
import { Performanceconstants } from 'src/app/constants/performanceconstants';

@Component({
  selector: 'app-homepageuser',
  templateUrl: './homepageuser.component.html',
  styleUrls: ['./homepageuser.component.scss']
})
export class HomepageuserComponent implements OnInit {

  errorMsg: string;
  login: string;
  showError: boolean;

  constructor() { }

  ngOnInit(): void {
    this.login = localStorage.getItem(Performanceconstants.USERNAME_KEY);
  }

}
