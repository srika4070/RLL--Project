import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewreceipesforuserComponent } from './viewreceipesforuser.component';

describe('ViewreceipesforuserComponent', () => {
  let component: ViewreceipesforuserComponent;
  let fixture: ComponentFixture<ViewreceipesforuserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewreceipesforuserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewreceipesforuserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
