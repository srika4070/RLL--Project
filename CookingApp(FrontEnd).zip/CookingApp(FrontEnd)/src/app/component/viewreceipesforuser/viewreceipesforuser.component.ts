import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertService, AuthenticationService } from 'src/app/_services';
import { Performanceconstants } from 'src/app/constants/performanceconstants';
import { LoginFlagService } from 'src/app/loginflag.service';
import { PerformancemanageService } from 'src/app/services/performancemanage.service';

@Component({
  selector: 'app-viewreceipesforuser',
  templateUrl: './viewreceipesforuser.component.html',
  styleUrls: ['./viewreceipesforuser.component.scss']
})
export class ViewreceipesforuserComponent implements OnInit {
  recipes: any[];
  loading = false;
  submitted = false;
  returnUrl: string;
  sucessMsg: string;
  showFailure: boolean;
  showLikes: boolean;
  likeMsg: string;
  failureMsg: string;
  showSucess: boolean;
  disableDuringSave: boolean;
  loadingServiceClassBtn: string;
  recipeCategories: any[];
  recipeForm: FormGroup;

  constructor(private formBuilder: FormBuilder,
     private route: ActivatedRoute,
    private router: Router,
    private authenticationService: AuthenticationService,
    private alertService: AlertService,
    private loginStatusService: LoginFlagService,
    private performanceManagerService: PerformancemanageService) { }

  ngOnInit(): void {
    this.recipeForm = this.formBuilder.group({
      recipecatname: [''],
      receipName:['']
    });
    this.loadRecepes();
    this.performanceManagerService.getRecipeCategories().subscribe(responseData => {
      this.recipeCategories = responseData.model;
    });
  }

  get f() { return this.recipeForm.controls; }

  get recipecatname(){
    return this.recipeForm.get('recipecatname');
  }

  get receipName(){
    return this.recipeForm.get('receipName');
  }

  loadRecepes(){
    this.performanceManagerService.getAllRecipes().subscribe(responseData => {
      this.recipes = responseData.model;
    });
  }
  
  failureHandling(err: string){
    this.loading = false;
    this.showFailure = true;
    this.showSucess = false;
    this.failureMsg = err;
    this.sucessMsg = '';
    this.likeMsg='';
    this.showLikes=false;
    this.loadingServiceClassBtn = Performanceconstants.NON_SPINNING_BTN_CLS;
  }

  sucessHandling(msg: string){
    this.loading = false;
    this.showFailure = false;
    this.showSucess = true;
    this.failureMsg = '';
    this.likeMsg='';
    this.showLikes=false;
    this.sucessMsg = msg;
    this.loadingServiceClassBtn = Performanceconstants.NON_SPINNING_BTN_CLS;
  }

  likeHandling(msg: string){
    this.loading = false;
    this.showFailure = false;
    this.showLikes = true;
    this.failureMsg = '';
    this.likeMsg = msg;
    this.loadingServiceClassBtn = Performanceconstants.NON_SPINNING_BTN_CLS;
  }

  showRecipeDetails(recipeId: number):void{
    //TODO: Navigate Receip Main Page
    const receiptIdTemp = recipeId;
    this.router.navigate(['/viewDetailsForDishForUser', receiptIdTemp]);
  }

  refreshContentForReceip(): void{
    let receiptcatname = this.recipeForm.get('recipecatname').value;
    let receipName = this.recipeForm.get('receipName').value;
    let tempData = {
      recipeCat: receiptcatname,
      receipName: receipName
    }
    this.performanceManagerService.getAllRecipesForCriteria(tempData).subscribe(responseData => {
      this.recipes = responseData.model;
    });
  }
  
}
