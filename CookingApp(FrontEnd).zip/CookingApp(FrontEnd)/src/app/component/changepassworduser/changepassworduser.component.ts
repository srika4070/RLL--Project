import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Orderpointconstants } from 'src/app/constants/orderpointconstants';
import { PerformancemanageService } from 'src/app/services/performancemanage.service';

@Component({
  selector: 'app-changepassworduser',
  templateUrl: './changepassworduser.component.html',
  styleUrls: ['./changepassworduser.component.scss']
})
export class ChangepassworduserComponent implements OnInit {
  
  validationError: string;
  loading = false;
  submitted = false;
  returnUrl: string;
  sucessMsg: string;
  showFailure = false;
  failureMsg: string;
  showSucess = false;
  showError: boolean;
  disableDuringSave: boolean;
  loadingServiceClassBtn: string;

  changePasswordForm: FormGroup;
  constructor(private formBuilder: FormBuilder,
    private performancemanageService: PerformancemanageService) { }

  ngOnInit(): void {
    this.changePasswordForm = this.formBuilder.group({
      oldauthinfo: ['', Validators.required],
      authinfo: ['', Validators.required]
    });
  }

  get oldauthinfo(){
    return this.changePasswordForm.get('oldauthinfo');
  }

  get authinfo(){
    return this.changePasswordForm.get('authinfo');
  }

  failureHandling(err: string){
    this.loading = false;
    this.showFailure = true;
    this.showSucess = false;
    this.failureMsg = err;
    this.sucessMsg = '';
    this.loadingServiceClassBtn = Orderpointconstants.NON_SPINNING_BTN_CLS;
  }

  sucessHandling(msg: string){
    this.loading = false;
    this.showFailure = false;
    this.showSucess = true;
    this.failureMsg = '';
    this.sucessMsg = msg;
    this.loadingServiceClassBtn = Orderpointconstants.NON_SPINNING_BTN_CLS;
  }

  get f() { return this.changePasswordForm.controls; }


  checkForChangePasswordValidity() {
    const status = false;
    const oldauthinfo = this.changePasswordForm.get('oldauthinfo').value;
    const authinfo = this.changePasswordForm.get('authinfo').value;
    if (oldauthinfo == null || oldauthinfo === '') {
      this.validationError = Orderpointconstants.OLDPASSWORD_ERROR;
      return true;
    } else if (authinfo == null || authinfo === '') {
      this.validationError = Orderpointconstants.NEWPASSWORD_ERROR;
      return true;
    }else {
      return false;
    }

  }

  changePassword(){

    this.loading = true;
    this.loadingServiceClassBtn = Orderpointconstants.SPINNING_BTN_CLS;
    if (this.checkForChangePasswordValidity()) {
    this.failureHandling(this.validationError);
    this.changePasswordForm.enable();
  } else {
    this.changePasswordForm.disable();
    const temp = this.changePasswordForm.value;
    if (temp.oldauthinfo === ''){
      temp.oldauthinfo = null;
    }

    if (temp.authinfo === ''){
      temp.authinfo = null;
    }

    const username = localStorage.getItem('username');
    console.log('==================================================');
    console.log(username);
    const orderInfo = {
      oldauthinfo: temp.oldauthinfo,
      authinfo: temp.authinfo,
      username: username
    };


    this.performancemanageService.changePassword(orderInfo).subscribe(
      (res) => {
        const status = res.status;

        if (status){

          const sucessMsg = res.sucessMsg;
          this.changePasswordForm.enable();
          this.sucessHandling(sucessMsg);
        }else{
          const errorV = res.errMessages[0].errMessage;
          this.failureHandling(errorV);
          this.changePasswordForm.enable();
        }

      },
      (error) => {
        this.changePasswordForm.enable();
        this.failureHandling(error);
      }
    );

  }

  }
}
