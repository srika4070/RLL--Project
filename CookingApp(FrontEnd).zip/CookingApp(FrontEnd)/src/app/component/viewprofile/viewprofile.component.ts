import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { AlertService, AuthenticationService, UserService } from 'src/app/_services';
import { Orderpointconstants } from 'src/app/constants/orderpointconstants';
import { PerformancemanageService } from 'src/app/services/performancemanage.service';

@Component({
  selector: 'app-viewprofile',
  templateUrl: './viewprofile.component.html',
  styleUrls: ['./viewprofile.component.scss']
})
export class ViewprofileComponent implements OnInit {
  registerForm: FormGroup;
  loading = false;
  submitted = false;
  validationError: string;
  returnUrl: string;
  sucessMsg: string;
  showFailure = false;
  failureMsg: string;
  showSucess = false;
  showError: boolean;
  disableDuringSave: boolean;
  loadingServiceClassBtn: string;
  authinfo: string;
  registerInfo: any;

  constructor( private formBuilder: FormBuilder,
    private router: Router,
    private authenticationService: AuthenticationService,
    private userService: UserService,
    private alertService: AlertService,
    private performanceManagerService: PerformancemanageService) { 

      const username = localStorage.getItem('username');
      this.performanceManagerService.getProfileForUser(username).subscribe(responseData => {
        this.registerInfo = responseData.model;
        this.setDataIntoForm(this.registerInfo);
      });

    }

    setDataIntoForm(registerInfo: any){
      this.authinfo = registerInfo.authinfo;
      
      const response = {
        firstname: registerInfo.firstname,
        lastname: registerInfo.lastname,
        email: registerInfo.email,
        phonenumber: registerInfo.phonenumber
      };
      // Set values from response to form controls
      this.registerForm.patchValue(response);
    }

  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      firstname: ['', Validators.required],
      lastname: ['', Validators.required],
      email: ['', Validators.required],
      phonenumber: ['',Validators.required]
    });
  }

  get f() { return this.registerForm.controls; }

  get firstname(){
    return this.registerForm.get('firstname');
  }

  get lastname(){
    return this.registerForm.get('lastname');
  }

  get email(){
    return this.registerForm.get('email');
  }

  get phonenumber(){
    return this.registerForm.get('phonenumber');
  }

  checkForProfileUpdateValidity() {
    const status = false;
    const firstname = this.registerForm.get('firstname').value;
    const lastname = this.registerForm.get('lastname').value;
    const email = this.registerForm.get('email').value;
    const phonenumber = this.registerForm.get('phonenumber').value;

    if (firstname == null || firstname === '') {
      this.validationError = Orderpointconstants.FIRST_NAME_ERROR;
      return true;
    } else if (lastname == null || lastname === '') {
      this.validationError = Orderpointconstants.LAST_NAME_ERROR;
      return true;
    }else if (email == null || email === '') {
      this.validationError = Orderpointconstants.EMAIL_ERROR;
      return true;
    }else if (phonenumber == null || phonenumber === '') {
      this.validationError = Orderpointconstants.PHONENO_ERROR;
      return true;
    }else {
      return false;
    }

  }

  onSubmit() {
   
    this.loading = true;
    this.loadingServiceClassBtn = Orderpointconstants.SPINNING_BTN_CLS;
    if (this.checkForProfileUpdateValidity()) {
    this.failureHandling(this.validationError);
    this.registerForm.enable();
  } else {
    this.registerForm.disable();
    const temp = this.registerForm.value;
   

    const username = localStorage.getItem('username');
    console.log('==================================================');
    console.log(username);
    const orderInfo = {
      firstname: temp.firstname,
      lastname: temp.lastname,
      email: temp.email,
      phonenumber: temp.phonenumber,
      username: username,
      authinfo: this.authinfo
    };


    this.performanceManagerService.updateProfile(orderInfo).subscribe(
      (res) => {
        const status = res.status;

        if (status){

          const sucessMsg = res.sucessMsg;
          this.registerForm.enable();
          this.sucessHandling(sucessMsg);
        }else{
          const errorV = res.errMessages[0].errMessage;
          this.failureHandling(errorV);
          this.registerForm.enable();
        }

      },
      (error) => {
        this.registerForm.enable();
        this.failureHandling(error);
      }
    );

  }
  
  }

  failureHandling(err: string){
    this.loading = false;
    this.showFailure = true;
    this.showSucess = false;
    this.failureMsg = err;
    this.sucessMsg = '';
    this.loadingServiceClassBtn = Orderpointconstants.NON_SPINNING_BTN_CLS;
  }

  sucessHandling(msg: string){
    this.loading = false;
    this.showFailure = false;
    this.showSucess = true;
    this.failureMsg = '';
    this.sucessMsg = msg;
    this.loadingServiceClassBtn = Orderpointconstants.NON_SPINNING_BTN_CLS;
  }

}
