import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/app/_models';
import { AuthenticationService } from 'src/app/_services';
import { Performanceconstants } from 'src/app/constants/performanceconstants';
import { LoginFlagService } from 'src/app/loginflag.service';

@Component({
  selector: 'app-navigationuser',
  templateUrl: './navigationuser.component.html',
  styleUrls: ['./navigationuser.component.scss']
})
export class NavigationuserComponent implements OnInit {

  userDetails: User;
  currentUserNav: boolean;
  loginStatusNav: boolean;
  login: string;
  constructor(
    private router: Router,
    private authService: AuthenticationService,
    private loginStatusService: LoginFlagService
    ) { }

  ngOnInit(): void {
    console.log('Performance Manager');
    this.login = localStorage.getItem(Performanceconstants.USERNAME_KEY);

  }

  updateTheFlagOfNav(userTemp: User){
    this.loginStatusNav = this.loginStatusService.getLoginStatus();
    if (userTemp.username != null && this.loginStatusNav){
      this.currentUserNav = true;
    }else if (localStorage.getItem('isLoggedIn') != null
     && localStorage.getItem('isLoggedIn') === 'YES'){
      this.currentUserNav = true;
    }
  }

  logoutNav() {
    localStorage.setItem('isLoggedIn', null);
    this.router.navigate(['/loginuser']);
  }

}
