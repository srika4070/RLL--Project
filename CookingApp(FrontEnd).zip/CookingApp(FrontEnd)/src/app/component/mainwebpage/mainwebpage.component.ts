import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mainwebpage',
  templateUrl: './mainwebpage.component.html',
  styleUrls: ['./mainwebpage.component.scss']
})
export class MainwebpageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
