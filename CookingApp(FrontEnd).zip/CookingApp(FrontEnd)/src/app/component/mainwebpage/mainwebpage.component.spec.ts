import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MainwebpageComponent } from './mainwebpage.component';

describe('MainwebpageComponent', () => {
  let component: MainwebpageComponent;
  let fixture: ComponentFixture<MainwebpageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MainwebpageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MainwebpageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
