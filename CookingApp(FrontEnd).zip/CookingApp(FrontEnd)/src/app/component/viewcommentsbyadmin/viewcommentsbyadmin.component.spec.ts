import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewcommentsbyadminComponent } from './viewcommentsbyadmin.component';

describe('ViewcommentsbyadminComponent', () => {
  let component: ViewcommentsbyadminComponent;
  let fixture: ComponentFixture<ViewcommentsbyadminComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewcommentsbyadminComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewcommentsbyadminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
