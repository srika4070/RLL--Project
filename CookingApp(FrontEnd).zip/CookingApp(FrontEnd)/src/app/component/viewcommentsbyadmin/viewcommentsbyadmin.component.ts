import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertService, AuthenticationService } from 'src/app/_services';
import { Performanceconstants } from 'src/app/constants/performanceconstants';
import { LoginFlagService } from 'src/app/loginflag.service';
import { PerformancemanageService } from 'src/app/services/performancemanage.service';

@Component({
  selector: 'app-viewcommentsbyadmin',
  templateUrl: './viewcommentsbyadmin.component.html',
  styleUrls: ['./viewcommentsbyadmin.component.scss']
})
export class ViewcommentsbyadminComponent implements OnInit {

  receiptId: string;
  commentsList: any[];
  loading = false;
  submitted = false;
  returnUrl: string;
  sucessMsg: string;
  showFailure: boolean;
  failureMsg: string;
  showSucess: boolean;
  disableDuringSave: boolean;
  loadingServiceClassBtn: string;

  constructor(private route: ActivatedRoute,
    private router: Router,
    private authenticationService: AuthenticationService,
    private alertService: AlertService,
    private loginStatusService: LoginFlagService,
    private performanceManagerService: PerformancemanageService) { }

  ngOnInit(): void {

    this.receiptId = this.route.snapshot.paramMap.get('receiptId');
    this.viewCommentsForRecepe(this.receiptId);


    
  }

  viewCommentsForRecepe(receiptId: string){
    this.performanceManagerService
    .fetchAllCommentsByRecepeId(receiptId)
    .subscribe(
      (res) => {
        const status = res.status;
        if (status){
          const sucessMsg = res.sucessMsg;
          this.sucessHandling(sucessMsg);
          this.commentsList = res.model;
        }else{
          const errorV = res.errMessages[0].errMessage;
          this.failureHandling(errorV);
        }
      },
      (error) => {
        this.failureHandling(error);
      }

    );
  }

  failureHandling(err: string){
    this.loading = false;
    this.showFailure = true;
    this.showSucess = false;
    this.failureMsg = err;
    this.sucessMsg = '';
    this.loadingServiceClassBtn = Performanceconstants.NON_SPINNING_BTN_CLS;
  }

  sucessHandling(msg: string){
    this.loading = false;
    this.showFailure = false;
    this.showSucess = true;
    this.failureMsg = '';
    this.sucessMsg = msg;
    this.loadingServiceClassBtn = Performanceconstants.NON_SPINNING_BTN_CLS;
  }

}
