import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appheader',
  templateUrl: './appheader.component.html',
  styleUrls: ['./appheader.component.scss']
})
export class AppheaderComponent implements OnInit {

  login: string;
  constructor() { }

  ngOnInit(): void {
  }

  logoutNav(){

  }

}
