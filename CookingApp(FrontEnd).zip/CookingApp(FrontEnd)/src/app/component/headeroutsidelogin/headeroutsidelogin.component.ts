import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-headeroutsidelogin',
  templateUrl: './headeroutsidelogin.component.html',
  styleUrls: ['./headeroutsidelogin.component.scss']
})
export class HeaderoutsideloginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
