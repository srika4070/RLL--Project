import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HeaderoutsideloginComponent } from './headeroutsidelogin.component';

describe('HeaderoutsideloginComponent', () => {
  let component: HeaderoutsideloginComponent;
  let fixture: ComponentFixture<HeaderoutsideloginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HeaderoutsideloginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderoutsideloginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
