import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DatepickerpocComponent } from './datepickerpoc.component';

describe('DatepickerpocComponent', () => {
  let component: DatepickerpocComponent;
  let fixture: ComponentFixture<DatepickerpocComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DatepickerpocComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatepickerpocComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
