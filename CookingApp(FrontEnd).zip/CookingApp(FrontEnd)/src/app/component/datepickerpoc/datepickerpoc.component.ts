import { Component, OnInit, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-datepickerpoc',
  templateUrl: './datepickerpoc.component.html',
  styleUrls: ['./datepickerpoc.component.scss']
})
export class DatepickerpocComponent implements OnInit {

  sampleForm: FormGroup;

  constructor(private formBuilder: FormBuilder,
              private eref: ElementRef) {
  }

  dynamicId;
  ngOnInit(): void {

  this.sampleForm = this.formBuilder.group({
    startDate: [null, Validators.required],
    startTime: [null, Validators.required],
    endDate: [null, Validators.required]
  });
  }
  getDetails() {
    const value = this.sampleForm.get('startDate').value;
    console.log(value);
    console.log('===================================');
    console.log(this.convertToValidString(value));
    console.log('End Date');
    const value1 = this.sampleForm.get('endDate').value;
    console.log(value1);
    console.log('===================================');
    console.log(this.convertToValidString(value1));
  }

  openDatepicker(id){
    this.dynamicId = id;
   }

  onClick(event) {
    console.log(event);
    if (this.dynamicId === undefined){
      console.log('Dynamic id ===============');
    }
    else if (!this.eref.nativeElement.contains(event.target)) {
      const self = this;
      // tslint:disable-next-line:only-arrow-functions
      setTimeout( function(){
        self.dynamicId.close();
      }, 10);
    }
  }

  convertToValidString(jsonDateObj){
    // YYYY-MM-DD
    if (jsonDateObj){
    return jsonDateObj.year + '-' + jsonDateObj.month + '-' +  jsonDateObj.day;
    }else{
      return '';
    }
  }

}
