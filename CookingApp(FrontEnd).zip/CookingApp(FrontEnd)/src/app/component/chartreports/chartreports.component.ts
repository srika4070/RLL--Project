import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { PerformancemanageService } from 'src/app/services/performancemanage.service';
import { Performanceconstants } from 'src/app/constants/performanceconstants';
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Color, Label } from 'ng2-charts';

@Component({
  selector: 'app-chartreports',
  templateUrl: './chartreports.component.html',
  styleUrls: ['./chartreports.component.scss']
})
export class ChartreportsComponent implements OnInit {

  disabledeviceid = true;
  validationError: string;
  chartreportform: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;
  sucessMsg: string;
  showFailure: boolean;
  failureMsg: string;
  showSucess: boolean;
  showError: boolean;
  disableDuringSave: boolean;
  loadingServiceClassBtn: string;

  DeviceList: any;
  ReportList: any;
  ChartList: any;

  public barChartLabels: Label[];


  public barChartOptions: ChartOptions = {
    responsive: true,
  };

  public barChartType: ChartType = 'bar';
  public barChartLegend = true;
  public barChartPlugins = [];
  public barChartData: ChartDataSets[] = [];


  constructor(private performancemanageService: PerformancemanageService,
              private formBuilder: FormBuilder) {

                this.performancemanageService.getUniqueReportNames().subscribe(
                  (respSucess) => {
                    if (respSucess.status){
                       this.ReportList = respSucess.model;

                    } else{
                      const errorResp = respSucess.errMessages[0].errMessage;
                      this.failureHandling(errorResp);
                    }
                  },
                  (errorResp) => {
                    this.failureHandling(errorResp);
                  }
                );

                this.performancemanageService.getDeviceInformation().subscribe(
                  (resp) => {
                    if (resp.status){
                      this.DeviceList = resp.model;
                    }else{
                      const errorV = resp.errMessages[0].errMessage;
                      this.failureHandling(errorV);
                    }
                  },
                  (errorResp) => {
                    this.failureHandling(errorResp);
                  }
                );

               }

  get f() { return this.chartreportform.controls; }
  ngOnInit(): void {

    this.chartreportform = this.formBuilder.group({
      devicename: ['', [Validators.required]],
      deviceid: new FormControl( {value: '', disabled: true}, Validators.required),
      reportname: ['', [Validators.required]],
      charttype: ['', [Validators.required]]
      });


  }

  changeDevice(deviceEvent){

    this.sucessMsg = '';
    this.showSucess = false;
    this.showError = false;
    this.failureMsg = '';
    console.log(deviceEvent);
    // tslint:disable-next-line:no-debugger

    const deviceType = deviceEvent.target.value;

    this.performancemanageService.getDeviceIdForDeviceType(deviceType).subscribe(
      (respSucess) => {
        if (respSucess.status){
           this.chartreportform.controls.deviceid.setValue(respSucess.model.deviceip);
        } else{
          const errorResp = respSucess.errMessages[0].errMessage;
          this.failureHandling(errorResp);
        }
      },
      (errorResp) => {
        this.failureHandling(errorResp);
      }
    );


    }

  get reportname(){
    return this.chartreportform.get('reportname');
   }

  get devicename(){
    return this.chartreportform.get('devicename');
  }

  get deviceid(){
    return this.chartreportform.get('deviceid');
  }

  get charttype(){
    return this.chartreportform.get('charttype');
  }

  failureHandling(err: string){
    this.loading = false;
    this.showFailure = true;
    this.showSucess = false;
    this.failureMsg = err;
    this.sucessMsg = '';
    this.loadingServiceClassBtn = Performanceconstants.NON_SPINNING_BTN_CLS;
  }

  sucessHandling(msg: string){
    this.loading = false;
    this.showFailure = false;
    this.showSucess = true;
    this.failureMsg = '';
    this.sucessMsg = msg;
    this.loadingServiceClassBtn = Performanceconstants.NON_SPINNING_BTN_CLS;
  }

  changeReport(event){

  }

  chartType(event){

  }

  generateChart(){

    this.loading = true;
    this.loadingServiceClassBtn = Performanceconstants.SPINNING_BTN_CLS;
    if (this.validateChartReportsForm()) {
      this.failureHandling(this.validationError);
      this.chartreportform.enable();
   } else {
      this.chartreportform.disable();

      const temp = this.chartreportform.value;

      if (temp.devicename === ''){
         temp.devicename = null;
      }


      if (temp.deviceid === ''){
        temp.deviceid = null;
      }

      if (temp.reportname === ''){
        temp.reportname = null;
      }

      if (temp.charttype === ''){
        temp.charttype = null;
      }

      const reportGenInfo = {
        devicename: temp.devicename,
        deviceid: temp.deviceid,
        reportname: temp.reportname,
        charttype: temp.charttype
      };

      this.performancemanageService.obtainChartInformation(reportGenInfo).subscribe(
        (res) => {
          const status = res.status;

          if (status){

            const sucessMsg = res.message;
            this.chartreportform.enable();
            this.sucessHandling(sucessMsg);

            // Obtaining the Chart Data



          }else{
            const errorV = res.errMessages[0].errMessage;
            this.failureHandling(errorV);
            this.chartreportform.enable();
          }

        },
        (error) => {
          this.chartreportform.enable();
          this.failureHandling(error);
        }
      );

   }



  }

  validateChartReportsForm() {
    const status = false;
    const devicename = this.chartreportform.get('devicename').value;
    const deviceid = this.chartreportform.get('deviceid').value;
    const reportname = this.chartreportform.get('reportname').value;
    const charttype = this.chartreportform.get('charttype').value;

    if (devicename == null || devicename === '') {
      this.validationError = Performanceconstants.DEVICENAME_ERROR;
      return true;
  } else if ((deviceid == null || deviceid === '')) {
      this.validationError = Performanceconstants.DEVICEID_ERROR;
      return true;
  } else if ((reportname == null || reportname === '')) {
    this.validationError = Performanceconstants.REPORTNAME_ERROR;
    return true;
  }else if ((charttype == null || charttype === '')) {
    this.validationError = Performanceconstants.CHARTTYPE_ERROR;
    return true;
  }else {

    return false;
  }

}




}

