import { Component, OnInit } from '@angular/core';
import { Performanceconstants } from 'src/app/constants/performanceconstants';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  errorMsg: string;
  login: string;
  showError: boolean;

  constructor() { }

  ngOnInit(): void {

   this.login = localStorage.getItem(Performanceconstants.USERNAME_KEY);
  }

}
