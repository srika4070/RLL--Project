import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewspecificrecipebyuserComponent } from './viewspecificrecipebyuser.component';

describe('ViewspecificrecipebyuserComponent', () => {
  let component: ViewspecificrecipebyuserComponent;
  let fixture: ComponentFixture<ViewspecificrecipebyuserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewspecificrecipebyuserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewspecificrecipebyuserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
