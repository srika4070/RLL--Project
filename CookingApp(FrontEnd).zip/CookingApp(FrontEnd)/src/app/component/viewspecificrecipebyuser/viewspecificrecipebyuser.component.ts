import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertService, AuthenticationService } from 'src/app/_services';
import { Orderpointconstants } from 'src/app/constants/orderpointconstants';
import { Performanceconstants } from 'src/app/constants/performanceconstants';
import { LoginFlagService } from 'src/app/loginflag.service';
import { PerformancemanageService } from 'src/app/services/performancemanage.service';

@Component({
  selector: 'app-viewspecificrecipebyuser',
  templateUrl: './viewspecificrecipebyuser.component.html',
  styleUrls: ['./viewspecificrecipebyuser.component.scss']
})
export class ViewspecificrecipebyuserComponent implements OnInit {
  receiptId: string;
  commentsList: any[];
  recipe: any;
  loading = false;
  submitted = false;
  returnUrl: string;
  sucessMsg: string;
  showFailure: boolean;
  showLikes: boolean;
  likeMsg: string;
  failureMsg: string;
  showSucess: boolean;
  disableDuringSave: boolean;
  loadingServiceClassBtn: string;
  commentsForm: FormGroup;
  validationError: string;

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private authenticationService: AuthenticationService,
    private alertService: AlertService,
    private loginStatusService: LoginFlagService,
    private performanceManagerService: PerformancemanageService) { }

  ngOnInit(): void {

    this.commentsForm = this.formBuilder.group({
      comments: ['', Validators.required]
    });

    this.receiptId = this.route.snapshot.paramMap.get('receiptId');
    this.viewSpecificRecipeForUI(this.receiptId);
    this.viewCommentsForRecepe(this.receiptId);
  }

  viewSpecificRecipeForUI(receiptId: string){
    this.performanceManagerService
    .viewSpecificRecipe(receiptId)
    .subscribe(
      (res) => {
        const status = res.status;
        if (status){
          const sucessMsg = res.sucessMsg;
          this.sucessHandling(sucessMsg);
          this.recipe = res.model;
        }else{
          const errorV = res.errMessages[0].errMessage;
          this.failureHandling(errorV);
        }
      },
      (error) => {
        this.failureHandling(error);
      }

    );
  }

  viewCommentsForRecepe(receiptId: string){
    this.performanceManagerService
    .fetchAllCommentsByRecepeId(receiptId)
    .subscribe(
      (res) => {
        const status = res.status;
        if (status){
          const sucessMsg = res.sucessMsg;
          this.sucessHandling(sucessMsg);
          this.commentsList = res.model;
        }else{
          const errorV = res.errMessages[0].errMessage;
          this.failureHandling(errorV);
        }
      },
      (error) => {
        this.failureHandling(error);
      }

    );
  }

  fetchLikes(recipeId: number):void{
   
    this.performanceManagerService.fetchLikes(recipeId).subscribe(
      (res) => {
        const status = res.status;
        if (status){
          const sucessMsg = res.sucessMsg;
          let likeDataObj = res.model;
          if(likeDataObj!=null){
            let likeActualDataObj = likeDataObj[0];
            if(likeActualDataObj!=null){
              this.likeHandling('The Number of Likes are '+ likeActualDataObj.likerecipe);
            }else{
              this.sucessHandling("No Likes Confirgured yet for recepe");
            }
          }else{
             this.sucessHandling(sucessMsg);
          }
        }else{
          const errorV = res.errMessages[0].errMessage;
          this.failureHandling(errorV);
        }
      },
      (error) => {
        this.failureHandling(error);
      }
    );
  }

  updateLike(recipeId: number):void{

    let likeObj = {
      recipeid: recipeId,
      like: 1
    }

    this.performanceManagerService.updateLike(likeObj).subscribe(
      (res) => {
        const status = res.status;
        if (status){
          const sucessMsg = res.sucessMsg;
          this.sucessHandling(sucessMsg);
         
        }else{
          const errorV = res.errMessages[0].errMessage;
          this.failureHandling(errorV);
        }
      },
      (error) => {
        this.failureHandling(error);
      }
    );

  }

  checkForValidComments() {
    const status = false;
    const comments = this.commentsForm.get('comments').value;
    if (comments == null || comments === '') {
      this.validationError = Orderpointconstants.OLDPASSWORD_ERROR;
      return true;
    } else {
      return false;
    }
  }

  addComment(){

    this.loading = true;
    this.loadingServiceClassBtn = Orderpointconstants.SPINNING_BTN_CLS;
    if (this.checkForValidComments()) {
    this.failureHandling(this.validationError);
    this.commentsForm.enable();
  } else {
    this.commentsForm.disable();
    const username = localStorage.getItem('username');
    console.log('==================================================');
    console.log(username);
    const comments = this.commentsForm.get('comments').value;
    const orderInfo = {
      comments: comments,
      recipeid: this.receiptId,
      username: username
    };


    this.performanceManagerService.addCommentForRecepe(orderInfo).subscribe(
      (res) => {
        const status = res.status;

        if (status){

          const sucessMsg = res.sucessMsg;
          this.commentsForm.enable();
          this.sucessHandling(sucessMsg);
        }else{
          const errorV = res.errMessages[0].errMessage;
          this.failureHandling(errorV);
          this.commentsForm.enable();
        }

      },
      (error) => {
        this.commentsForm.enable();
        this.failureHandling(error);
      }
    );

  }

  }


  failureHandling(err: string){
    this.loading = false;
    this.showFailure = true;
    this.showSucess = false;
    this.failureMsg = err;
    this.sucessMsg = '';
    this.likeMsg='';
    this.showLikes=false;
    this.loadingServiceClassBtn = Performanceconstants.NON_SPINNING_BTN_CLS;
  }

  sucessHandling(msg: string){
    this.loading = false;
    this.showFailure = false;
    this.showSucess = true;
    this.failureMsg = '';
    this.likeMsg='';
    this.showLikes=false;
    this.sucessMsg = msg;
    this.loadingServiceClassBtn = Performanceconstants.NON_SPINNING_BTN_CLS;
  }

  likeHandling(msg: string){
    this.loading = false;
    this.showFailure = false;
    this.showLikes = true;
    this.failureMsg = '';
    this.likeMsg = msg;
    this.loadingServiceClassBtn = Performanceconstants.NON_SPINNING_BTN_CLS;
  }

}
