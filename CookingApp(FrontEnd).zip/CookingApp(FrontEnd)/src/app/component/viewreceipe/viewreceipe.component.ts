import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertService, AuthenticationService } from 'src/app/_services';
import { Performanceconstants } from 'src/app/constants/performanceconstants';
import { LoginFlagService } from 'src/app/loginflag.service';
import { PerformancemanageService } from 'src/app/services/performancemanage.service';

@Component({
  selector: 'app-viewreceipe',
  templateUrl: './viewreceipe.component.html',
  styleUrls: ['./viewreceipe.component.scss']
})
export class ViewreceipeComponent implements OnInit {
  recipes: any[];
  loading = false;
  submitted = false;
  returnUrl: string;
  sucessMsg: string;
  showFailure: boolean;
  showLikes: boolean;
  likeMsg: string;
  failureMsg: string;
  showSucess: boolean;
  disableDuringSave: boolean;
  loadingServiceClassBtn: string;

  constructor( private route: ActivatedRoute,
    private router: Router,
    private authenticationService: AuthenticationService,
    private alertService: AlertService,
    private loginStatusService: LoginFlagService,
    private performanceManagerService: PerformancemanageService) { }

  ngOnInit(): void {
   this.loadRecepes();
  }

  loadRecepes(){
    this.performanceManagerService.getAllRecipes().subscribe(responseData => {
      this.recipes = responseData.model;
    });
  }
  
  failureHandling(err: string){
    this.loading = false;
    this.showFailure = true;
    this.showSucess = false;
    this.failureMsg = err;
    this.sucessMsg = '';
    this.likeMsg='';
    this.showLikes=false;
    this.loadingServiceClassBtn = Performanceconstants.NON_SPINNING_BTN_CLS;
  }

  sucessHandling(msg: string){
    this.loading = false;
    this.showFailure = false;
    this.showSucess = true;
    this.failureMsg = '';
    this.likeMsg='';
    this.showLikes=false;
    this.sucessMsg = msg;
    this.loadingServiceClassBtn = Performanceconstants.NON_SPINNING_BTN_CLS;
  }

  likeHandling(msg: string){
    this.loading = false;
    this.showFailure = false;
    this.showLikes = true;
    this.failureMsg = '';
    this.likeMsg = msg;
    this.loadingServiceClassBtn = Performanceconstants.NON_SPINNING_BTN_CLS;
  }

  deleteRecipe(recipeId: number): void {
    this.performanceManagerService.deleteRecipe(recipeId).subscribe(
      (res) => {
        const status = res.status;
        if (status){
          const sucessMsg = res.sucessMsg;
          this.sucessHandling(sucessMsg);
          this.recipes = [];
          this.loadRecepes();
        }else{
          const errorV = res.errMessages[0].errMessage;
          this.failureHandling(errorV);
        }
      },
      (error) => {
        this.failureHandling(error);
      }
    );
  }

  fetchLikes(recipeId: number):void{

    
    this.performanceManagerService.fetchLikes(recipeId).subscribe(
      (res) => {
        const status = res.status;
        if (status){
          const sucessMsg = res.sucessMsg;
          let likeDataObj = res.model;
          if(likeDataObj!=null){
            let likeActualDataObj = likeDataObj[0];
            if(likeActualDataObj!=null){
              this.likeHandling('The Number of Likes are '+ likeActualDataObj.likerecipe);
            }else{
              this.sucessHandling("No Likes Confirgured yet for recepe");
            }
          }else{
             this.sucessHandling(sucessMsg);
          }
        }else{
          const errorV = res.errMessages[0].errMessage;
          this.failureHandling(errorV);
        }
      },
      (error) => {
        this.failureHandling(error);
      }
    );
  }

  showComments(recipeId: number){

    const receiptIdTemp = recipeId;
    this.router.navigate(['/viewCommentsByAdminForRecipe', receiptIdTemp]);
  }

}
