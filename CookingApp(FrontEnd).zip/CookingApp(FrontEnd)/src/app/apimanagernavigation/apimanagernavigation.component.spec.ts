import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ApiManagerNavigationComponent } from './apimanagernavigation.component';


describe('ApimanagernavigationComponent', () => {
  let component: ApiManagerNavigationComponent;
  let fixture: ComponentFixture<ApiManagerNavigationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApiManagerNavigationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApiManagerNavigationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
