import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../_services';
import { User } from '../_models';
import { LoginFlagService } from '../loginflag.service';
import { Performanceconstants } from '../constants/performanceconstants';


@Component({
  selector: 'app-apimanagernavigation',
  templateUrl: './apimanagernavigation.component.html',
  styleUrls: ['./apimanagernavigation.component.scss']
})
export class ApiManagerNavigationComponent implements OnInit {

  userDetails: User;
  currentUserNav: boolean;
  loginStatusNav: boolean;
  login: string;
  constructor(
    private router: Router,
    private authService: AuthenticationService,
    private loginStatusService: LoginFlagService
    ) { }

  ngOnInit(): void {
    console.log('Performance Manager');
    this.login = localStorage.getItem(Performanceconstants.USERNAME_KEY);

  }

  updateTheFlagOfNav(userTemp: User){
    this.loginStatusNav = this.loginStatusService.getLoginStatus();
    if (userTemp.username != null && this.loginStatusNav){
      this.currentUserNav = true;
    }else if (localStorage.getItem('isLoggedIn') != null
     && localStorage.getItem('isLoggedIn') === 'YES'){
      this.currentUserNav = true;
    }
  }

  logoutNav() {
    localStorage.setItem('isLoggedIn', null);
    this.router.navigate(['/']);
  }

}
