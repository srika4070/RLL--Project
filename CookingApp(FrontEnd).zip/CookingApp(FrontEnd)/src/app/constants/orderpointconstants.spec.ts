import { Orderpointconstants } from './orderpointconstants';

describe('Orderpointconstants', () => {
  it('should create an instance', () => {
    expect(new Orderpointconstants()).toBeTruthy();
  });
});
