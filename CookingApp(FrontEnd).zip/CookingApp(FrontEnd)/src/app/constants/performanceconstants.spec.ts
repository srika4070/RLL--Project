import { Performanceconstants } from './performanceconstants';

describe('Performanceconstants', () => {
  it('should create an instance', () => {
    expect(new Performanceconstants()).toBeTruthy();
  });
});
