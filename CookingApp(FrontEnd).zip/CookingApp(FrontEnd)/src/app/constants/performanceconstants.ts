export class Performanceconstants {

  public static USERNAME_KEY = 'username';

  public static SPINNING_BTN_CLS = 'spinner-border spinner-border-sm';

  public static NON_SPINNING_BTN_CLS = '';

  public static DEVICENAME_ERROR = 'Please Select the Device Name';

  public static FROMDATE_ERROR = 'From Date Cannot be Empty';

  public static DEVICEID_ERROR = 'Device ID Cannot be Empty';

  public static TODATE_ERROR = 'To Date Cannot be Empty';

  public static MINUTES_ERROR = 'Please Select Minutes';

  public static REPORTNAME_ERROR = 'Please Select Report Name';

  public static CHARTTYPE_ERROR = 'Chart Type is Empty';

}
