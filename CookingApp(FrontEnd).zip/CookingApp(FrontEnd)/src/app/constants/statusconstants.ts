export class StatusConstants {

  static CLASS_WARNING = 'alert alert-warning';

  static STATUS_PROCESSING_CLASS1 = 'spinner-grow text-warning';

  static STATUS_PROCESSING_DONE  = '';

  static STATUS_PROCESSING_CLASS2 = 'spinner-border text-primary';

  static STATUS_PROCESSING_CLASS3 = 'spinner-border text-warning';

  static STATUS_PROCESSING_CLASS4 = 'spinner-grow text-warning';

  static STATUS_SERVICE_TAB_PROCESSING = 'Loading ...';

  static STATUS_OPERATION_TAB_PROCESSING = 'Loading ...';

  static PROCESSING_COMPLETED = ' ';

  static STATUS_PROCESSING_REQERROR = 'Processing of Request Response Classes has Failed';

  static STATUS_PROCESSING_OPERATIONERROR = 'Proccessing of Operations in Service Definition has Failed';

  static STATUS_PROCESSING_NOSERVICEIDFOUND = 'No Service Found Please try later';

  static INTERNAL_ERROR = 'An Internal Error Occured. Contact System Admin';
}
