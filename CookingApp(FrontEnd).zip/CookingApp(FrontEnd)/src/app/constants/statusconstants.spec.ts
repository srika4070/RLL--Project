import { Statusconstants } from './statusconstants';

describe('Statusconstants', () => {
  it('should create an instance', () => {
    expect(new Statusconstants()).toBeTruthy();
  });
});
