export class Orderpointconstants {

  public static SPINNING_BTN_CLS = 'spinner-border spinner-border-sm';

  public static NON_SPINNING_BTN_CLS = '';

  public static ORDERNAME_ERROR = 'Please Provide Order Name';

  public static CUSTOMERNAME_ERROR = 'Please Select Customer Name';

  public static PRODUCTOFFERINGNAME_ERROR = 'Please Select Product Offering';

  public static STATUS_ERROR = 'Please Provide Status';

  public static ASSIGNED_VALUE_ERROR = 'Please select Assignee';

  public static SEARCHORDERBY_ERROR = 'Search Order By must be either Customer Id or Order Name';

  public static SEARCHDATA_ERROR = 'Search Data must be selected';

  public static OLDPASSWORD_ERROR = 'Old Password Cannot be Empty';

  public static NEWPASSWORD_ERROR = 'New Password Cannot be Empty';

  public static CONFIRMNEWPASSWORD_ERROR = 'Confirm New Password Cannot be Empty';

  public static FIRST_NAME_ERROR = "First Name cannot be empty";

  public static LAST_NAME_ERROR = "Last Name cannot be empty";

  public static EMAIL_ERROR = "Email Address cannot be empty";

  public static  PHONENO_ERROR = "Phone Number cannot be empty";
}
