import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, of, throwError} from 'rxjs';
import { environment } from 'src/environments/environment';
import { catchError } from 'rxjs/operators'; // Import catchError
const httpOptions = {
  headers: new HttpHeaders({'Content-Type': 'application/json'})
};

@Injectable({
  providedIn: 'root'
})
export class PerformancemanageService {

  constructor(private http: HttpClient) { }
  
  doLogin(data: any): Observable<any> {
    return this.http.post<any>(environment.config.serverUrl + 'login', data, httpOptions)
      .pipe(
        catchError((error: HttpErrorResponse) => this.handleError(error))
      );
  }

  private handleError(error: HttpErrorResponse): Observable<any> {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong.
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    // Return an observable with a user-facing error message.
    return throwError('Something bad happened; please try again later.');
  }

  submitRecipe(formData: FormData): Observable<any> {
    return this.http.post<any>(environment.config.serverUrl + 'recipe', formData);
  }
  updateProfile(data: any){
    return this.http.put<any>(environment.config.serverUrl + 'user', data, httpOptions);
  }
  updateLike(data:any){
    return this.http.post<any>(environment.config.serverUrl + 'recipelike', data, httpOptions);
  }

  addCommentForRecepe(data:any){
    return this.http.post<any>(environment.config.serverUrl + 'recipecomments', data, httpOptions);
  }

  getAllRecipesForCriteria(data:any){
    return this.http.post<any>(environment.config.serverUrl + '/recipe/fetchAllByCriteria', data, httpOptions);
  }

  getRecipeCategories(): Observable<any> {
    return this.http.get<any>(environment.config.serverUrl + 'recipecat');
  }

  getAllRecipes(): Observable<any> {
    return this.http.get<any>(environment.config.serverUrl + 'recipe/fetchAllRecipe');
  }

  getAllRecipesForCatName(catName: string): Observable<any>{
    return this.http.get<any>(environment.config.serverUrl + 'recipe/fetchAllRecipeByCatName/'+catName);
  }

  viewSpecificRecipe(recipeId: string): Observable<any> {
    return this.http.get<any>(environment.config.serverUrl +'recipe/fetchByRecipeId/'+recipeId);
  }

  deleteRecipe(recipeId: number): Observable<any> {
    return this.http.delete<any>(environment.config.serverUrl +'delete/byRecepeId/'+recipeId);
  }

  fetchLikes(recipeId: number): Observable<any>{
    return this.http.get<any>(environment.config.serverUrl +'recipelike/byReceipId/'+recipeId);
  }

  fetchAllCommentsByRecepeId(recipeId: string): Observable<any>{
    return this.http.get<any>(environment.config.serverUrl +'recipecomments/byRecipeId/'+recipeId);
  }

  changePassword(data: any): Observable<any>{
    return this.http.post<any>(environment.config.serverUrl + 'changePassword', data, httpOptions);
  }

  getProfileForUser(username: string): Observable<any> {
    return this.http.get<any>(environment.config.serverUrl + 'user/fetchByUserName/'+username, httpOptions);
  }

  getDeviceInformation(): Observable<any> {
    return this.http.get<any>(environment.config.serverUrl + 'retriveAllDeviceInformation', httpOptions);
  }

  getDeviceIdForDeviceType(data: string): Observable<any> {
    return this.http.get<any>(environment.config.serverUrl + 'retriveAllDeviceInformation/' + data, httpOptions);
  }

  getIntervalInformation(): Observable<any> {
    return this.http.get<any>(environment.config.serverUrl + 'retriveAllIntervalInformation', httpOptions);
  }

  generateReportInformation(data: any): Observable<any>{
    return this.http.post<any>(environment.config.serverUrl + 'generateReport', data, httpOptions);
  }

  saveReportInformation(data: any): Observable<any>{
    return this.http.post<any>(environment.config.serverUrl + 'saveReport', data, httpOptions);
  }

  getUniqueReportNames(): Observable<any> {
    return this.http.get<any>(environment.config.serverUrl + 'retriveReportNameAll', httpOptions);
  }


  searchReportInformation(data: any): Observable<any>{
    return this.http.post<any>(environment.config.serverUrl + 'searchReportByCriteria', data, httpOptions);
  }

  getUniqueChartNames(): Observable<any> {
    return this.http.get<any>(environment.config.serverUrl + 'retriveUniqueChartNames', httpOptions);
  }

  obtainChartInformation(data: any): Observable<any> {
    return this.http.post<any>(environment.config.serverUrl + 'obtainchartdata', data, httpOptions);
  }

}
