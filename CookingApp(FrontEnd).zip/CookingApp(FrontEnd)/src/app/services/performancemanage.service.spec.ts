import { TestBed } from '@angular/core/testing';

import { PerformancemanageService } from './performancemanage.service';

describe('PerformancemanageService', () => {
  let service: PerformancemanageService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PerformancemanageService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
