import { Operation } from './operation';

describe('Operation', () => {
  it('should create an instance', () => {
    expect(new Operation()).toBeTruthy();
  });
});
