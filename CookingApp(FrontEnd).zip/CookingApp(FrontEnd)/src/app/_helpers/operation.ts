export class Operation {
  createdDate: string;
  createdBy: string ;
  updatedDate: string;
  modifiedBy: string ;
  operationId: string ;
  name: string ;
  soapAction: string  ;
  appOperationName: string ;
  requestJSONLocation: string ;
  responseJSONLocation: string ;
  dbUrl: string;
  dbUser: string;
  dbPass: string;
  dbQuery: string;
  requestClass: string ;
  responseClass: string ;
  classMetadata: string;



}
