import { ApiManagerConstants } from '../apimanagerconstants';
import { Operation } from './operation';

export class Helper {

  static appendPackageToArray(classArray: string, packageName: string){

    const tempList = new Array<string>();

    const classArray1 = classArray.split(ApiManagerConstants.SPLITTER_APPENDER);

    classArray1.forEach((temp) => { const temp1 = packageName + ApiManagerConstants.DOT_APPENDER + temp ;
                                    tempList.push(temp1);
    });

    return tempList;
  }

  static findOperationsFromOperationObject(operations: any[]){
    // tslint:disable-next-line:prefer-const
    let operationList = new Array<string>();
    operations.forEach(operation => {
      operationList.push(operation.name);
    });
    return operationList;
  }

  static findOperationIdByName(serviceDef: any, name: string){

  const  operationsArray = serviceDef.operations;
  let operationId = '';
  if (operationsArray){

    for (const operationtemp of operationsArray) {
      if (operationtemp.name === name){
        operationId = operationtemp.operationId;
        return operationId;
      }
    }

    return operationId;
  }

  }

  static findAppOperationByName(serviceDef: any, name: string){
    const  operationsArray = serviceDef.operations;
    let operationName = '';
    if (operationsArray){

    for (const operationtemp of operationsArray) {
      if (operationtemp.name === name){
        operationName = operationtemp.appOperationName;
        return operationName;
      }
    }

    return operationName;
  }

  }

  static convertUIObjectToOperationsServiceRequest(operationFormData: any, operationId: string){
    const obj = {
      operationId: '',
      name: '',
      requestClass: '',
      responseClass: '',
      requestJSONLocation: '',
      responseJSONLocation: '',
      appOperationName: ''
    };
   // obj = new Operation();

    obj.operationId = operationId;

    if (operationFormData.hasOwnProperty('name')){
      obj.name = operationFormData.name;
    }

    if (operationFormData.hasOwnProperty('requestClass')){
      obj.requestClass = operationFormData.requestClass;
    }

    if (operationFormData.hasOwnProperty('responseClass')){
      obj.responseClass = operationFormData.responseClass;
    }

    if (operationFormData.hasOwnProperty('requestJSONLocation')){
      // obj.requestJSONLocation = 'C:/work/techurate/CustomerQueryReq.json';
       obj.requestJSONLocation = '/home/admin/apimanager/CustomerQueryReq.json';
    }

    if (operationFormData.hasOwnProperty('responseJSONLocation')){
      // obj.responseJSONLocation = 'C:/work/techurate/CustomerDetailsRep.json';
        obj.responseJSONLocation = '/home/admin/apimanager/CustomerDetailsRep.json';
    }

    if (operationFormData.hasOwnProperty('appOperationName')){
      obj.appOperationName = operationFormData.appOperationName;
    }

    return obj;

  }

  static processResponseMappingAndEnhanceObj(resmapjsondata: any){
    const processedJson = {

      fieldList: []
     };

    const temp = resmapjsondata.Response;

    const fieldListTemp = {
      name: '',
      fqnClassName: '',
      id: '',
      metadataID: '',
      type: '',
      source: '',
      system: '',
      children: [],
      jsonMapClass: ''
    };


    fieldListTemp.name = 'Response';
    fieldListTemp.fqnClassName = temp.fqnClassName;
    fieldListTemp.id = 'ResponseID';
    fieldListTemp.metadataID = temp.metadataID;
    fieldListTemp.type = temp.type;
    fieldListTemp.source = temp.source;
    fieldListTemp.system = temp.system;
    fieldListTemp.children = temp.fieldList;
    if (temp.hasOwnProperty('jsonMapClass')){
       fieldListTemp.jsonMapClass = temp.jsonMapClass;
    }

    processedJson.fieldList[0] = fieldListTemp;
    return processedJson;


  }

  static processRequestMappingAndEnhanceObj(reqmapjsondata: any){

    const processedJson = {

      fieldList: []
     };

    const temp = reqmapjsondata.Request;

    const fieldListTemp = {
      name: '',
      fqnClassName: '',
      id: '',
      metadataID: '',
      type: '',
      source: '',
      system: '',
      children: [],
      jsonMapClass: ''
    };


    fieldListTemp.name = 'Request';
    fieldListTemp.fqnClassName = temp.fqnClassName;
    fieldListTemp.id = 'RequestID';
    fieldListTemp.metadataID = temp.metadataID;
    fieldListTemp.type = temp.type;
    fieldListTemp.source = temp.source;
    fieldListTemp.system = temp.system;
    fieldListTemp.children = temp.fieldList;
    if (temp.hasOwnProperty('jsonMapClass')){
      fieldListTemp.jsonMapClass = temp.jsonMapClass;
   }

    processedJson.fieldList[0] = fieldListTemp;
    return processedJson;

  }

  static prepareRootNodeRequest(jsonObj: any, selectedValue: string){
    const jsonRes =
      {
        metadataID: '',
        jsonMapClass: '',
        fqnClassName: '',
        type: '',
        source: '',
        system: ''
    };

    if (jsonObj.hasOwnProperty('metadataID') && jsonObj.metadataID){
       jsonRes.metadataID = jsonObj.metadataID;
    }

    jsonRes.jsonMapClass = selectedValue;

    if (jsonObj.hasOwnProperty('fqnClassName') && jsonObj.fqnClassName){
      jsonRes.fqnClassName = jsonObj.fqnClassName;
   }

    if (jsonObj.hasOwnProperty('type') && jsonObj.type){
    jsonRes.type = jsonObj.type;
   }

    if (jsonObj.hasOwnProperty('source') && jsonObj.source){
    jsonRes.source = jsonObj.source;
   }

    if (jsonObj.hasOwnProperty('system') && jsonObj.system){
    jsonRes.system = jsonObj.system;
   }

    return jsonRes;
  }

static  prepareParentNodeRequest(jsonObj: any, selectedValue: string){
    const jsonRes = jsonObj;
    jsonRes.mapField = selectedValue;
    return jsonRes;
  }

static prepareRequestForChildNodeWithNoParent(jsonObj, formJson){

  const requestJSON =
    {
      path: '',
      name: '',
      type: '',
      required: false,
      children: [],
      id: '',
      mask: false,
      mapField: '',
      defaultValue: '',
      validationRegEx: ''
    };

  requestJSON.path = jsonObj.path;
  requestJSON.name = jsonObj.name;
  requestJSON.type = jsonObj.type;
  requestJSON.required = formJson.required;

  if (jsonObj.hasOwnProperty('children')){
    requestJSON.children = jsonObj.children;
  }

  requestJSON.validationRegEx  = formJson.validationRegEx;


  requestJSON.id = jsonObj.id;
  requestJSON.mask = formJson.mask;
  requestJSON.mapField = formJson.mapField;
  requestJSON.defaultValue = formJson.defaultValue;

  return requestJSON;
}


}
