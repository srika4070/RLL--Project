import { Apimanagervalidator } from './apimanagervalidator';

describe('Apimanagervalidator', () => {
  it('should create an instance', () => {
    expect(new Apimanagervalidator()).toBeTruthy();
  });
});
