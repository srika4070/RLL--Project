import { AbstractControl, ValidationErrors } from '@angular/forms';

export class Apimanagervalidator {

static cannotContainSpace(control: AbstractControl): ValidationErrors | null {
   console.log('cannotContainSpace');
   if ((control.value as string).indexOf(' ') >= 0){
      return {cannotContainSpace: true };
  }

   return null;
}

static invalidUrl(control: AbstractControl): ValidationErrors | null {
  const URL_REGEXP = /^(http?|ftp):\/\/([a-zA-Z0-9.-]+(:[a-zA-Z0-9.&%$-]+)*@)*((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]?)(\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])){3}|([a-zA-Z0-9-]+\.)*[a-zA-Z0-9-]+\.(com|edu|gov|int|mil|net|org|biz|arpa|info|name|pro|aero|coop|museum|[a-zA-Z]{2}))(:[0-9]+)*(\/($|[a-zA-Z0-9.,?'\\+&%$#=~_-]+))*$/;
  if ((control.value as string).indexOf(' ') >= 0){
    return {invalidUrl: true };
  }else if (control.value && control.value.length > 0 && !URL_REGEXP.test(control.value)){
    return {invalidUrl: true };
  }
  return null;
}

static versionvalidator(control: AbstractControl): ValidationErrors | null {
    const VERSION_REGEXP =  /^[0-9]*\.?[0-9]*$/;
    console.log('Version Validator Called');


    if ((control.value) && (control.value as string) && (control.value.toString() as string).indexOf(' ') >= 0){
      return {versionvalidator: true };
    }else if (control.value && control.value.length > 0){
      const testversion = control.value.match(VERSION_REGEXP);
      if (null == testversion){
      return {versionvalidator: true };
      }else{
        return null;
      }
    }
    return null;
}


}
