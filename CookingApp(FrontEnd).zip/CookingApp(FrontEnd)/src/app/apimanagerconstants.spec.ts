import { Apimanagerconstants } from './apimanagerconstants';

describe('Apimanagerconstants', () => {
  it('should create an instance', () => {
    expect(new Apimanagerconstants()).toBeTruthy();
  });
});
