import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register';
import { ChangePasswordComponent } from './change.password/change.password.component';
import { HomeComponent } from './component/home/home.component';
import { ReportgenComponent } from './component/reportgen/reportgen.component';
import { DatepickerpocComponent } from './component/datepickerpoc/datepickerpoc.component';
import { HomepageuserComponent } from './component/homepageuser/homepageuser.component';
import { RecepegenComponent } from './component/recepegen/recepegen.component';
import { ViewreceipeComponent } from './component/viewreceipe/viewreceipe.component';
import { ViewcommentsbyadminComponent } from './component/viewcommentsbyadmin/viewcommentsbyadmin.component';
import { LoginuserComponent } from './component/loginuser/loginuser.component';
import { ViewprofileComponent } from './component/viewprofile/viewprofile.component';
import { ViewreceipesforuserComponent } from './component/viewreceipesforuser/viewreceipesforuser.component';
import { ChangepassworduserComponent } from './component/changepassworduser/changepassworduser.component';
import { ViewspecificrecipebyuserComponent } from './component/viewspecificrecipebyuser/viewspecificrecipebyuser.component';
import { MainwebpageComponent } from './component/mainwebpage/mainwebpage.component';
const routes: Routes = [
  { path: 'register', component: RegisterComponent },
  { path: 'loginuser', component: LoginuserComponent },
  { path: '', component: MainwebpageComponent },
  {path:'login', component:LoginComponent},
  { path: 'mainwebpage', component: MainwebpageComponent },
   { path: 'home', component: HomeComponent},
  { path: 'homepageuser', component: HomepageuserComponent},
  { path: 'viewprofile', component: ViewprofileComponent},
  { path: 'viewreceipesuser', component: ViewreceipesforuserComponent},
  { path: 'changepass', component: ChangePasswordComponent},
  { path: 'viewreceipesforuser', component: ViewreceipesforuserComponent},
  { path: 'changepassword', component: ChangePasswordComponent},
  { path: 'changepassworduser', component: ChangepassworduserComponent},
  { path: 'reportgen', component: ReportgenComponent},  
  { path: 'addreceipe', component: RecepegenComponent},
  { path: 'viewreceipes', component: ViewreceipeComponent},
  { path: 'viewCommentsByAdminForRecipe/:receiptId', component: ViewcommentsbyadminComponent},
  { path: 'viewDetailsForDishForUser/:receiptId', component: ViewspecificrecipebyuserComponent},
  { path: 'datepickerpoc', component: DatepickerpocComponent},
  { path: '**', redirectTo: '' }
];

export const appRoutingModule = RouterModule.forRoot(routes);
