import { BrowserModule } from '@angular/platform-browser';
import { ChartsModule } from 'ng2-charts';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppComponent } from './app.component';
import { AgGridModule } from 'ag-grid-angular';
import { HttpClientModule,HTTP_INTERCEPTORS } from '@angular/common/http';
import { LoginComponent } from './login/login.component';
import { appRoutingModule } from './app.routing';
import { AlertComponent } from './alert/alert.component';
import { RegisterComponent } from './register';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { TreeModule } from 'angular-tree-component';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { JwtInterceptor, ErrorInterceptor, fakeBackendProvider } from './_helpers';
import { ApiManagerNavigationComponent } from './apimanagernavigation/apimanagernavigation.component';
import { HttpModule } from '@angular/http';
import { MarkAsteriskDirective } from './directives/mark-asterisk.directive';
import { ChangePasswordComponent } from './change.password/change.password.component';
import { HomeComponent } from './component/home/home.component';
import { AppheaderComponent } from './component/appheader/appheader.component';
import { ReportgenComponent } from './component/reportgen/reportgen.component';
import { DatepickerInputComponent } from './component/datepicker-input/datepicker-input.component';
import { DatepickerpocComponent } from './component/datepickerpoc/datepickerpoc.component';
import { ChartreportsComponent } from './component/chartreports/chartreports.component';
import { HomepageuserComponent } from './component/homepageuser/homepageuser.component';
import { RecepegenComponent } from './component/recepegen/recepegen.component';
import { ViewreceipeComponent } from './component/viewreceipe/viewreceipe.component';
import { ViewcommentsbyadminComponent } from './component/viewcommentsbyadmin/viewcommentsbyadmin.component';
import { LoginuserComponent } from './component/loginuser/loginuser.component';
import { NavigationuserComponent } from './component/navigationuser/navigationuser.component';
import { ViewprofileComponent } from './component/viewprofile/viewprofile.component';
import { ViewreceipesforuserComponent } from './component/viewreceipesforuser/viewreceipesforuser.component';
import { ChangepassworduserComponent } from './component/changepassworduser/changepassworduser.component';
import { ViewspecificrecipebyuserComponent } from './component/viewspecificrecipebyuser/viewspecificrecipebyuser.component';
import { MainwebpageComponent } from './component/mainwebpage/mainwebpage.component';
import { HeaderoutsideloginComponent } from './component/headeroutsidelogin/headeroutsidelogin.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AlertComponent,
    RegisterComponent,
    ApiManagerNavigationComponent,
    HeaderoutsideloginComponent,
    MarkAsteriskDirective,
    ChangePasswordComponent,
    HomeComponent,
    AppheaderComponent,
    ReportgenComponent,
    DatepickerInputComponent,
    DatepickerpocComponent,
    ChartreportsComponent,
    HomepageuserComponent,
    RecepegenComponent,
    ViewreceipeComponent,
    ViewcommentsbyadminComponent,
    LoginuserComponent,
    NavigationuserComponent,
    ViewprofileComponent,
    ViewreceipesforuserComponent,
    ChangepassworduserComponent,
    ViewspecificrecipebyuserComponent,
    MainwebpageComponent,
    HeaderoutsideloginComponent
  ],
  imports: [
        BrowserModule,
        ReactiveFormsModule,
        HttpClientModule,
        appRoutingModule,
        AgGridModule.withComponents(),
        NgbModule,
        TreeModule.forRoot(),
        TypeaheadModule.forRoot(),
        BrowserAnimationsModule,
        HttpModule,
        FormsModule,
        ChartsModule
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },

    // provider used to create fake backend
    fakeBackendProvider],
  bootstrap: [AppComponent]
})
export class AppModule { }
