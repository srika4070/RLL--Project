import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginFlagService {

  loginStatus: boolean;
  constructor() { }

  setLoginStatus(tempLogin: boolean){
    this.loginStatus = tempLogin;
  }

  getLoginStatus(){
    return this.loginStatus;
  }
}
