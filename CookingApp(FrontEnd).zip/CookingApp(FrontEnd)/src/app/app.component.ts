import { Component, OnInit, ViewChild} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AgGridAngular } from 'ag-grid-angular';
import { AuthenticationService } from './_services';
import { Router } from '@angular/router';
import { User } from './_models';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit{
  currentUser: User;

  constructor(
    private router: Router,
    private authService: AuthenticationService
  ){
    this.authService.currentUser.subscribe(x => this.currentUser = x);
  }

  ngOnInit(): void {
    console.log('AppComponent Logging is Sucessful');
  }

  logout(): void {
    this.router.navigate(['/']);
  }
}
