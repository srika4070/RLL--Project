import { TestBed } from '@angular/core/testing';
import { LoginFlagService } from './loginflag.service';



describe('LoginflagserviceService', () => {
  let service: LoginFlagService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LoginflagserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
