export const environment = {
  production: true,
  config: {
    apiUrl: 'http://localhost:4200',
    serverUrl: 'http://34.93.119.26:8080/'
  }
};
